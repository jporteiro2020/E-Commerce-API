delete from venta;
delete from consola;
delete from notebook;
delete from pcsEscritorio;
delete from producto;
delete from usuario;